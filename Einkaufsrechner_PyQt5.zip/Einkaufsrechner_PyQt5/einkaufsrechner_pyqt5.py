import sys, os
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton, QVBoxLayout, QLabel
from PyQt5.QtGui import QIcon

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(BASE_DIR, "einkaufsliste_icon.jpg")


# Fenster
class Myapp(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Einkaufsrechner")
        self.setWindowIcon(QIcon(ICON_PATH))  # ← FIX: Icon hier setzen (drinnen, nicht oben)
        self.resize(700, 500)


        layout = QVBoxLayout()

        # ← NEU: Abstände/Spacing
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)



        label = QLabel('Willkommen bei den Einkaufsrechnerprogramm.\nDu kannst hiermit deinen Preis errechnen lassen, mit den passenden Artikel.')
        layout.addWidget(label)

        # Eingabefelder
        self.eingabe_artikel = QLineEdit()
        self.eingabe_artikel.setPlaceholderText('Artikel')
        layout.addWidget(self.eingabe_artikel)

        self.eingabe_menge = QLineEdit()
        self.eingabe_menge.setPlaceholderText('Menge')
        layout.addWidget(self.eingabe_menge)

        self.eingabe_preis = QLineEdit()
        self.eingabe_preis.setPlaceholderText('Preis')
        layout.addWidget(self.eingabe_preis)

        self.ausgabe = QLabel("")
        layout.addWidget(self.ausgabe)

        # Wichtig: Layout anwenden
        self.setLayout(layout)
        self.show()

        # Button
        button = QPushButton("OK")
        layout.addWidget(button)
        button.clicked.connect(self.update_text)

        # ← NEU: Stylesheet (einfaches Dark-Theme)
        self.setStyleSheet("""
        QLabel {
            background-color: #3b82f6;   /* Akzent-Hintergrund fürs Label (optional) */
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 6px 8px;
            color: #000000;              /* Schrift schwarz */
            font-family: "Segoe UI", Cantarell, Arial;
            font-size: 14px;
        }

        QWidget {
            background-color: #90EE90;   /* hellgrün */
            color: #000000;              /* Schrift schwarz */
            font-family: "Segoe UI", Cantarell, Arial;
            font-size: 20px;
        }

        QLineEdit {
            background-color: #ADD8E6;   /* Akzent */
            color: #000000;              /* Schrift schwarz */
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 6px 8px;
        }

        QLineEdit:focus {
            background-color: #ADD8E6;   /* hellblau im Fokus */
            border: 1px solid #3b82f6;
        
        }

        QPushButton {
            background-color: #ADD8E6;   /* hellblau */
            color: #000000;              /* Button-Schrift schwarz */
            border: none;
            border-radius: 8px;
            padding: 8px 12px;
            font-weight: bold;
        }

        QPushButton:hover  { background-color: #9CC7E0; }
        QPushButton:pressed{ background-color: #8CB8D3; }
        """)

    def update_text(self):
        # Sting in Zahlen umwandeln
        artikel = self.eingabe_artikel.text()
        menge = float(self.eingabe_menge.text().replace(",", "."))
        preis = float(self.eingabe_preis.text().replace(",", "."))
        ergebnis = menge * preis

        # Text im Label anzeigen
        text = (
            f'Du kaufst {menge}x {artikel} zum Preis von {preis} EUR pro Stück.\n'
            f'Der Gesamtpreis beträgt: {ergebnis} €'
        )
        self.ausgabe.setText(text)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Myapp()
    sys.exit(app.exec_())







